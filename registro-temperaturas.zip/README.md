# 🌡️ Registro de Temperaturas Diarias

Este proyecto es un ejemplo de **manejo de arreglos multidimensionales (matrices 3D) en Python**.  
La aplicación registra temperaturas diarias en varias ciudades, durante varias semanas, y calcula los **promedios semanales** por ciudad.

---

## 📌 Estructura de la Matriz 3D

- **Primera dimensión** → Ciudades  
- **Segunda dimensión** → Semanas  
- **Tercera dimensión** → Días de la semana (Lunes - Domingo)  

Ejemplo conceptual:

```
temperaturas[ciudad][semana][día]
```

---

## 🔧 Funcionalidad

1. Se generan temperaturas aleatorias entre **10°C y 35°C**.  
2. Se recorren las 3 dimensiones con **bucles anidados**.  
3. Se calcula el **promedio de temperaturas** por ciudad y semana.  
4. Se muestra en pantalla:  
   - Promedio de cada ciudad/semana.  
   - Detalle de todas las temperaturas registradas.  

---

## ▶️ Ejecución del programa

Clonar el repositorio:

```bash
git clone https://github.com/TU-USUARIO/registro-temperaturas.git
```

Entrar al directorio del proyecto:

```bash
cd registro-temperaturas
```

Ejecutar el script:

```bash
python temperaturas.py
```

---

## 📚 Tecnologías utilizadas
- Python 3.10+
- Programación con listas (arrays/matrices)
- Bucles anidados
- Operaciones matemáticas básicas
