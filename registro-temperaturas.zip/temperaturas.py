# Registro de Temperaturas Diarias
# Matriz 3D: [ciudades][semanas][días]

import random

# Definimos las dimensiones
ciudades = ["Quito", "Guayaquil", "Cuenca"]
dias_semana = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
num_semanas = 2

# Inicializamos la matriz 3D con temperaturas ficticias
temperaturas = []

for ciudad in ciudades:
    semanas = []
    for s in range(num_semanas):
        dias = []
        for d in dias_semana:
            # Generamos una temperatura aleatoria entre 10 y 35 grados
            temp = random.randint(10, 35)
            dias.append(temp)
        semanas.append(dias)
    temperaturas.append(semanas)

# Cálculo de promedios por ciudad y semana
print("PROMEDIO DE TEMPERATURAS POR CIUDAD Y SEMANA\n")

for i, ciudad in enumerate(ciudades):
    for s in range(num_semanas):
        suma = 0
        for d in range(len(dias_semana)):
            suma += temperaturas[i][s][d]
        promedio = suma / len(dias_semana)
        print(f"{ciudad} - Semana {s+1}: {promedio:.2f} °C")
    print("-" * 40)

# (Opcional) Mostrar todas las temperaturas registradas
print("\nDETALLE DE TEMPERATURAS REGISTRADAS\n")
for i, ciudad in enumerate(ciudades):
    print(f"Ciudad: {ciudad}")
    for s in range(num_semanas):
        print(f"  Semana {s+1}: {temperaturas[i][s]}")
    print()
